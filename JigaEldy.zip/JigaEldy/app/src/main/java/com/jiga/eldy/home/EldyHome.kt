package com.jiga.eldy.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.jiga.eldy.R

class EldyHome : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_eldy_home)
    }
}